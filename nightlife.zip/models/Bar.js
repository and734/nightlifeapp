// models/Bar.js
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const BarSchema = new Schema({
  yelpId: { // Yelp's ID for the bar
    type: String,
    required: true,
    unique: true // Important to prevent duplicates
  },
  name: {
    type: String,
    required: true
  },
  imageUrl: { // URL to the bar's image
    type: String,
  },
  address: {
    type: String
  },
  going: [{
    type: Schema.Types.ObjectId,
    ref: 'User'  // Array of User IDs who are going
  }],
  coordinates: {
    latitude: Number,
    longitude: Number
  }
});

module.exports = mongoose.model('Bar', BarSchema);
