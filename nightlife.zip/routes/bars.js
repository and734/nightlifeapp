// routes/bars.js
const express = require('express');
const router = express.Router();
const axios = require('axios');
const Bar = require('../models/Bar');
const { ensureAuthenticated } = require('../config/auth');  // Import ensureAuthenticated correctly

// Yelp API Endpoint
const YELP_API_BASE_URL = 'https://api.yelp.com/v3/businesses/search';

// Search Bars by Location (Requires Yelp API Key)
router.get('/search', async (req, res) => {
  const { location } = req.query;
  const apiKey = process.env.YELP_API_KEY;

  if (!apiKey) {
    return res.status(500).json({ error: 'Yelp API key not configured.' });
  }

  try {
    const response = await axios.get(YELP_API_BASE_URL, {
      headers: {
        Authorization: `Bearer ${apiKey}`,
      },
      params: {
        location,
        term: 'bars',
        limit: 20, // Adjust as needed
      },
    });

    const bars = response.data.businesses.map(business => ({
      yelpId: business.id,
      name: business.name,
      imageUrl: business.image_url,
      address: `${business.location.address1}, ${business.location.city}, ${business.location.state} ${business.location.zip_code}`,
      coordinates: business.coordinates
    }));

    // Check if bars exist in our DB, if not add them.
    for (const bar of bars) {
      const existingBar = await Bar.findOne({ yelpId: bar.yelpId });
      if (!existingBar) {
        const newBar = new Bar(bar);
        await newBar.save();
      }
    }

    const barIds = bars.map(bar => bar.yelpId);

    // Fetch bars from our DB to get the going information
    const dbBars = await Bar.find({ yelpId: { $in: barIds } }).populate('going');

    res.json(dbBars);

  } catch (error) {
    console.error('Yelp API Error:', error);
    res.status(500).json({ error: 'Failed to fetch bars from Yelp.' });
  }
});

// Update User Going to a Bar (Requires Authentication)
router.post('/:barId/going', ensureAuthenticated, async (req, res) => {
  const barId = req.params.barId;
  const userId = req.user.id;

  try {
    const bar = await Bar.findOne({ yelpId: barId });

    if (!bar) {
      return res.status(404).json({ error: 'Bar not found' });
    }

    if (bar.going.includes(userId)) {
      return res.status(400).json({ error: 'User already going to this bar' });
    }

    bar.going.push(userId);
    await bar.save();

    // Populate the 'going' field to return the user details
    await bar.populate('going');

    res.json(bar);
  } catch (error) {
    console.error('Error updating bar:', error);
    res.status(500).json({ error: 'Failed to update bar' });
  }
});

// Remove User from a Bar (Requires Authentication)
router.delete('/:barId/going', ensureAuthenticated, async (req, res) => {
  const barId = req.params.barId;
  const userId = req.user.id;

  try {
    const bar = await Bar.findOne({ yelpId: barId });

    if (!bar) {
      return res.status(404).json({ error: 'Bar not found' });
    }

    bar.going = bar.going.filter(id => id.toString() !== userId);
    await bar.save();

    await bar.populate('going');

    res.json(bar);
  } catch (error) {
    console.error('Error removing user from bar:', error);
    res.status(500).json({ error: 'Failed to remove user from bar' });
  }
});

module.exports = router; // Export the router
