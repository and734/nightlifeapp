// src/App.js (Example)
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import BarList from './components/BarList';
import SearchBar from './components/SearchBar';
import Login from './components/Login';
import Register from './components/Register';
import Navbar from './components/Navbar';

function App() {
  const [bars, setBars] = useState([]);
  const [city, setCity] = useState('');
  const [user, setUser] = useState(null); // User object if logged in
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
      setIsLoggedIn(true);
    }
  }, []);


  const searchBars = async (location) => {
    try {
      const response = await axios.get(`/api/bars/search?location=${location}`);
      setBars(response.data);
      setCity(location); // Store the searched city
    } catch (error) {
      console.error('Error fetching bars:', error);
    }
  };

  const handleGoing = async (barId) => {
    try {
      const response = await axios.post(`/api/bars/${barId}/going`);
      const updatedBar = response.data;

      setBars(bars.map(bar => bar.yelpId === updatedBar.yelpId ? updatedBar : bar));
    } catch (error) {
      console.error('Error adding user to bar:', error);
      if (error.response && error.response.status === 401) {
        alert("Please login to update the going list")
      }
    }
  };

  const handleNotGoing = async (barId) => {
    try {
      const response = await axios.delete(`/api/bars/${barId}/going`);
      const updatedBar = response.data;

      setBars(bars.map(bar => bar.yelpId === updatedBar.yelpId ? updatedBar : bar));
    } catch (error) {
      console.error('Error removing user from bar:', error);
      if (error.response && error.response.status === 401) {
        alert("Please login to update the going list")
      }
    }
  };

  const handleLogin = (userData) => {
    setUser(userData);
    setIsLoggedIn(true);
    localStorage.setItem('user', JSON.stringify(userData)); // Store user data in localStorage
    // Optionally re-search for bars in the previously searched city
    if (city) {
      searchBars(city);
    }
  };

  const handleLogout = async () => {
    try {
      await axios.get('/api/users/logout');
      setUser(null);
      setIsLoggedIn(false);
      localStorage.removeItem('user'); // Remove user data from localStorage
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  return (
    <div>
      <Navbar isLoggedIn={isLoggedIn} onLogout={handleLogout} />
      <h1>Nightlife Coordination</h1>
      {isLoggedIn ? (
        <>
          <SearchBar onSearch={searchBars} />
          <BarList bars={bars} onGoing={handleGoing} onNotGoing={handleNotGoing} userId={user.id} />
        </>
      ) : (
        <>
          <Login onLogin={handleLogin} />
          <Register />
          <SearchBar onSearch={searchBars} />
          <BarList bars={bars} onGoing={() => alert('Please log in to indicate you are going.')} onNotGoing={() => alert('Please log in to indicate you are no longer going.')} userId={null} />
          <p>Please log in to indicate you are going to a bar.</p>

        </>
      )}

    </div>
  );
}

export default App;

