// src/components/BarList.js
import React from 'react';

function BarList({ bars, onGoing, onNotGoing, userId }) {
  return (
    <ul>
      {bars && bars.map(bar => (
        <li key={bar.yelpId}>
          {bar.name} - {bar.going ? bar.going.length : 0} people going
          {userId ? (
            bar.going && bar.going.some(user => user._id === userId) ? (
              <button onClick={() => onNotGoing(bar.yelpId)}>Not Going</button>
            ) : (
              <button onClick={() => onGoing(bar.yelpId)}>Going</button>
            )
          ) : (
            <button onClick={() => alert('Please log in to indicate you are going.')}>Going</button>
          )}
        </li>
      ))}
    </ul>
  );
}

export default BarList;
