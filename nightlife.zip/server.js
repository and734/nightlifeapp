const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const passport = require('passport');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const dotenv = require('dotenv');
const path = require('path');
const helmet = require('helmet');

dotenv.config();  // Load environment variables from .env

const app = express();
const port = process.env.PORT || 3000;  // Use environment variable for port

// Check for required environment variables
if (!process.env.MONGODB_URI) {
  console.error('FATAL ERROR: MONGODB_URI is not defined.  Exiting...');
  process.exit(1); // Exit with an error code
}
if (!process.env.YELP_API_KEY) {
  console.error('FATAL ERROR: YELP_API_KEY is not defined. Exiting...');
  process.exit(1);
}

// CORS Configuration (Adjust for production)
const corsOptions = {
  origin: process.env.NODE_ENV === 'production' ? 'https://your-frontend-domain.com' : '*', // Replace with your frontend URL in production
  credentials: true, // Allow cookies to be sent in cross-origin requests (if needed)
};

// Middleware
app.use(cors(corsOptions));
app.use(express.json()); // Parse JSON request bodies
app.use(express.urlencoded({ extended: true }));  // Parse URL-encoded bodies

// Session Configuration (Production-Ready)
app.use(session({
  secret: process.env.SESSION_SECRET || 'your-secret-key',
  resave: false,
  saveUninitialized: false,
  store: MongoStore.create({ mongoUrl: process.env.MONGODB_URI }),
  cookie: {
    secure: process.env.NODE_ENV === 'production', // Only send cookie over HTTPS in production
    httpOnly: true, // Prevent client-side JavaScript from accessing the cookie
    maxAge: 7 * 24 * 60 * 60 * 1000, // Session duration (e.g., 7 days)
    sameSite: 'strict' // Help prevent CSRF attacks
  }
}));

// Passport middleware
app.use(passport.initialize());
app.use(passport.session());

// Passport Config
require('./config/passport')(passport); // Load passport configuration

// Routes
const userRoutes = require('./routes/users');
const barRoutes = require('./routes/bars');
app.use('/api/users', userRoutes);
app.use('/api/bars', barRoutes);

// Serve static assets if in production
if (process.env.NODE_ENV === 'production') {
  app.use(express.static('client/build'));

  app.get('*', (req, res) => {
    res.sendFile(path.resolve(__dirname, 'client', 'build', 'index.html'));
  });
}

// MongoDB Connection
mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log('MongoDB connected'))
.catch(err => console.log(err));

mongoose.connection.on('disconnected', () => {
  console.log('MongoDB disconnected!');
  // Implement reconnection logic here (e.g., try to reconnect after a delay)
});

// Security Headers (Use Helmet in production)
if (process.env.NODE_ENV === 'production') {
  app.use(helmet());
}

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
